# Contact

## For Fabrication Help
Email: amexsimoes@gmail.com

## What to Include
1. Your name/institution
2. Foundry access details
3. Intended use (research/commercial)

## Response Time
Typically 24-48 hours.
