# Φ-24 TEMPORAL RESONATOR - FABRICATION LICENSE
## Agreement Number: TT-FAB-Φ24-2026-001

===============================================================================
IMPORTANT - READ CAREFULLY BEFORE FABRICATION
===============================================================================

This document governs the fabrication of the Φ-24 Temporal Resonator 
("the Device") as defined in the accompanying GDSII files, technical 
specifications, and fabrication protocols.

===============================================================================
1. INTELLECTUAL PROPERTY STATUS
===============================================================================

1.1 Patent Protection
    ────────────────────────────────────────────────────────────────────────
    The Device architecture, including but not limited to:
    • 21-layer Fibonacci superlattice with golden ratio modulation
    • Phase-snapping Josephson junction arrays
    • 24D Riemann manifold mapping methodology
    • Prime-Specific Error Correction (P-ECC) algorithms
    • Temporal wedge isolation structures
    
    is protected by:
    • US Provisional Patent Application No. 63/XXX,XXX (filed February 2026)
    • PCT International Application No. PCT/US2026/XXXXX (pending)
    • Australian Provisional Application No. 2026XXXXXXXX (pending)
    
    All rights reserved. Unauthorized commercial exploitation is prohibited.

1.2 Copyright
    ────────────────────────────────────────────────────────────────────────
    • GDSII layout files (phi24_core.gds) © 2026 A. Simões, CTT Research
    • Fabrication specifications and technical documentation © 2026 CTT Research
    • All rights reserved under Berne Convention and 17 U.S.C. §101 et seq.

===============================================================================
2. PERMITTED FABRICATION
===============================================================================

2.1 Research and Academic Use
    ────────────────────────────────────────────────────────────────────────
    Without separate written license, the following are PERMITTED:

    a) Non-commercial academic research institutions may fabricate up to 
       10 (ten) Devices per calendar year for internal research only.

    b) Government laboratories may fabricate up to 5 (five) Devices per 
       calendar year for verification and validation purposes.

    c) Individual researchers may fabricate up to 2 (two) Devices for 
       personal research, non-commercial use only.

    CONDITIONS APPLY:
    • Full attribution must appear on all publications and presentations
    • Research results must be shared with CTT Research upon request
    • Devices may not be sold, leased, or transferred to third parties
    • Reverse engineering for commercial purposes is strictly prohibited

2.2 Attribution Requirement
    ────────────────────────────────────────────────────────────────────────
    All permitted fabrications must include the following attribution 
    in visible location on Device packaging and in any publications:

    ```
    Φ-24 Temporal Resonator
    Designed by A. Simões, CTT Research 2026
    Protected by US Patent Application 63/XXX,XXX
    ```

===============================================================================
3. PROHIBITED ACTIVITIES
===============================================================================

The following activities are STRICTLY PROHIBITED without prior written license:

3.1 Commercial Fabrication
    ────────────────────────────────────────────────────────────────────────
    • Manufacturing Devices for sale, lease, or commercial distribution
    • Integrating Devices into commercial products or systems
    • Providing fabrication services to third parties
    • Volume production exceeding permitted research limits

3.2 Intellectual Property Violations
    ────────────────────────────────────────────────────────────────────────
    • Reverse engineering of GDSII files or fabricated Devices
    • Filing patent applications containing Device architecture
    • Removal or alteration of attribution markings
    • Unauthorized distribution of fabrication files

3.3 Export Control Violations
    ────────────────────────────────────────────────────────────────────────
    • Export to countries subject to ITAR/EAR restrictions
    • Transfer to entities on denied persons lists
    • Use in weapons systems without explicit authorization

===============================================================================
4. COMMERCIAL LICENSING
===============================================================================

4.1 Obtaining a Commercial License
    ────────────────────────────────────────────────────────────────────────
    Commercial fabrication, volume production, and integration into 
    products require a separate written license agreement.

    CONTACT:
    Licensing Department
    CTT Research Group
    Email: licensing@ctt-science.org
    Signal: +65 8763 5603

    Please include:
    • Intended use case and production volume
    • Technical contact information
    • Proposed timeline

4.2 License Types Available
    ────────────────────────────────────────────────────────────────────────
    • Foundry License: Per-wafer fabrication authorization
    • Integration License: Device integration into commercial products
    • Technology Transfer License: Full IP package for internal development
    • Evaluation License: Time-limited testing and validation

===============================================================================
5. WARRANTY DISCLAIMER
===============================================================================

THE DEVICE DESIGN AND ASSOCIATED DOCUMENTATION ARE PROVIDED "AS IS" 
WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
PURPOSE, OR NON-INFRINGEMENT.

CTT Research Group and A. Simões assume no liability for any damages 
arising from fabrication, use, or inability to use the Device design.

===============================================================================
6. GOVERNING LAW
===============================================================================

This License shall be governed by the laws of New South Wales, Australia, 
without regard to conflict of law principles.

===============================================================================
7. ACCEPTANCE
===============================================================================

By fabricating the Device, you acknowledge that you have read and agree 
to the terms of this License.

===============================================================================
DOCUMENT CONTROL
===============================================================================

Version:     1.0
Status:      Final
Date:        February 12, 2026
Author:      A. Simões, CTT Research
Supersedes:  All prior versions

===============================================================================
CONTACT INFORMATION
===============================================================================

Technical Inquiries:    amexsimoes@gmail.com
Licensing:              amexsimoes@gmail.com
Legal:                  amexsimoes@gmail.com
General:                amexsimoes@gmail.com

===============================================================================
© 2026 CTT Research Group. All rights reserved.
===============================================================================
